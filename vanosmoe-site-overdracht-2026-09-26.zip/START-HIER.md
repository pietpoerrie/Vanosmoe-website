# Van os Moe — website, overdrachtspakket

**Datum:** 26 september 2026 · samengesteld door 't is gefixt

Dit pakket bevat de volledige website van Van os Moe: alle code, alle content,
alle foto's. Het draait zonder externe diensten — er is geen CMS, geen database,
geen API-sleutel nodig om te bouwen. Zet het op een eigen Cloudflare-account en
het staat live.

```
START-HIER.md          ← dit bestand
site/                  ← de volledige website
  ├── HANDOVER.md      ← ★ begin hier: hoe content wijzigen en publiceren
  ├── README.md        ← structuur en stack
  └── DEPLOY.md        ← deploy-procedure en domeinen
```

---

## Eerst even proberen

```bash
cd site
npm install
npm run dev      # http://localhost:4321
```

Draait dat, dan draait alles. De build heeft geen netwerk nodig, dus wat lokaal
werkt, werkt ook bij de hoster.

---

## Op een eigen Cloudflare-account zetten

**1. Code in een eigen git-repo.** Maak een repo (GitHub of GitLab) en zet de
inhoud van `site/` erin — dus `package.json` in de root van die repo, niet de map
`site` zelf.

**2. Cloudflare Pages koppelen.** In het Cloudflare-dashboard: *Workers & Pages →
Create → Pages → Connect to Git*, kies de repo, en neem deze instellingen over:

| Instelling | Waarde |
|---|---|
| Framework preset | Astro (of *None*) |
| Build command | `npm run build` |
| Build output directory | `dist` |
| Node version | `22` |
| Environment variables | **geen** |

**3. Deploy en nakijken.** Cloudflare bouwt en geeft een URL op `*.pages.dev`.
Loop die na met de checklist onderaan `site/DEPLOY.md`: homepage, een
productpagina, `/vind-ons`, en `/sitemap.xml` (hoort 15 URL's te geven).

**4. Pas daarna het domein omzetten.** `vanosmoe.be` staat vandaag in het
Cloudflare-account van 't is gefixt en wijst naar de bestaande Pages-site. Zolang
stap 3 niet groen is, mag daar niets aan veranderen — anders gaat de site plat.
Zodra de nieuwe build goed staat, wordt in onderling overleg de zone verhuisd of
het DNS-record omgezet. **Dit is een gecoördineerde stap, geen solo-actie.**

---

## Twee dingen die op naam van 't is gefixt staan

Deze werken vandaag, maar horen vervangen te worden:

1. **De Google Maps-key** voor de kaart op `/vind-ons`. Staat in
   `site/src/data/site.ts` als `mapsApiKey`, met uitleg erboven. Maak een eigen
   key in Google Cloud (Maps Embed API) en beperk hem tot het eigen domein.
2. **Het Cloudflare-account en de DNS-zone** — zie stap 4 hierboven.

---

## Wat je niet mag aanraken

- **`shop.vanosmoe.be`** is de webshop op Linkedfarm, een extern platform met
  eigen logistiek en B2B-netwerk. De site linkt ernaartoe, meer niet. Niet
  integreren, niet vervangen, het DNS-record met rust laten.
- **De tagline mag nooit breken op "van os moe".** *"Niks smaakt zo goe als de
  soep van os moe"* — de regelafbreking hoort vóór "de soep" te vallen.

De volledige lijst staat in `site/HANDOVER.md` onder *Niet doen*, telkens met de
reden erbij.

---

## Nog open

| Punt | |
|---|---|
| Contact-e-mail | Staat nog op `pieter_goris@hotmail.com` (`site/src/data/site.ts`). Vervangen zodra er een bedrijfsmail is. |
| SEO-verbeteringen | Zitten in de code maar draaien nog niet op de huidige live site — canonical tags, een H1 op de homepage, en schema.org-markup voor producten en recepten. De eerste deploy brengt ze mee. |

---

## Over de content

Alle teksten, producten, recepten en pagina's staan als markdown in
`site/src/content/`. Een tekst wijzigen is een bestand wijzigen; de build
controleert of de velden kloppen en geeft een duidelijke fout als er iets niet
klopt. `site/HANDOVER.md` legt per soort content uit welke velden er zijn en wat
ze doen — begin daar.

De huisstijl (logo's, kleuren, lettertypes, templates en een `AGENTS.md` met de
merkregels als instructies) zit in een apart pakket:
**`vanosmoe-brandkit-codex-2026.08.1.zip`**.
